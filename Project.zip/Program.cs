/****************************************************************************
**					SAKARYA �N�VERS�TES�
**				B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				   NESNEYE DAYALI PROGRAMLAMA DERS�
**					2023-2024 BAHAR D�NEM�
**	
**				�DEV NUMARASI..........: 1
**				��RENC� ADI............: Ayhan Dalk�ran
**				��RENC� NUMARASI.......: G221210020
**				DERS�N ALINDI�I GRUP...: II. ��retim C
****************************************************************************/
namespace Project;

internal static class Program {
	/// <summary>
	///  The main entry point for the application.
	/// </summary>
	[System.STAThread]
	static void Main() {
		// To customize application configuration such as set high DPI settings or default font,
		// see https://aka.ms/applicationconfiguration.
		ApplicationConfiguration.Initialize();
		System.Windows.Forms.Application.Run(new MainForm());
	}
}